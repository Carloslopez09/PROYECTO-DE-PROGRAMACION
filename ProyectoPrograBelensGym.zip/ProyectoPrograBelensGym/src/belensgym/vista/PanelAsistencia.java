/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Db;
import belensgym.util.Estilo;
import belensgym.util.Sesion;
import belensgym.util.Ui;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author carlo
 */
public class PanelAsistencia extends javax.swing.JPanel implements Recargable {
     private final java.util.ArrayList<Integer> idsCoach = new java.util.ArrayList<>();

    /**
     * Creates new form PanelAsistencia
     */
    public PanelAsistencia() {
        
        initComponents();
        txtDesde.setText(LocalDate.now().withDayOfMonth(1).toString());
        txtHasta.setText(LocalDate.now().toString());
        Estilo.tabla(tabla);
        Estilo.campo(txtDesde, txtHasta);
        Estilo.primario(btnEntrada);
        Estilo.secundario(btnSalida);
        Estilo.secundario(btnFiltrar);
        // El coach ve sus botones; el administrador ve el filtro por coach
        boolean esCoach = Sesion.esCoach();
        btnEntrada.setVisible(esCoach && Sesion.idCoach != null);
        btnSalida.setVisible(esCoach && Sesion.idCoach != null);
        lblCoach.setVisible(!esCoach);
        cmbCoach.setVisible(!esCoach);
        btnEntrada.addActionListener(e -> marcarEntrada());
        btnSalida.addActionListener(e -> marcarSalida());
        btnFiltrar.addActionListener(e -> recargar());
        recargar();
    }
    
    private void cargarCoaches() {
        try {
            int seleccionado = 0;
            int pos = cmbCoach.getSelectedIndex();
            if (pos >= 0 && pos < idsCoach.size()) {
                seleccionado = idsCoach.get(pos);
            }
            DefaultTableModel m = Db.consultar(
                    "SELECT id_coach, CONCAT(nombres, ' ', apellidos) FROM coaches ORDER BY nombres");
            javax.swing.DefaultComboBoxModel<String> modelo = new javax.swing.DefaultComboBoxModel<>();
            idsCoach.clear();
            modelo.addElement("Todos");
            idsCoach.add(0);
            for (int i = 0; i < m.getRowCount(); i++) {
                idsCoach.add(((Number) m.getValueAt(i, 0)).intValue());
                modelo.addElement(String.valueOf(m.getValueAt(i, 1)));
            }
            cmbCoach.setModel(modelo);
            cmbCoach.setSelectedIndex(Math.max(0, idsCoach.indexOf(seleccionado)));
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    public void recargar() {
        java.sql.Date desde;
        java.sql.Date hasta;
        try {
            desde = Ui.fecha(txtDesde.getText());
            hasta = Ui.fecha(txtHasta.getText());
            if (desde == null || hasta == null) {
                throw new IllegalArgumentException();
            }
        } catch (IllegalArgumentException e) {
            Ui.error(this, "Fechas inválidas. Usa el formato AAAA-MM-DD.");
            return;
        }
        try {
            if (!Sesion.esCoach()) {
                cargarCoaches();
            }
            StringBuilder sql = new StringBuilder(
                    "SELECT a.id_asistencia AS `ID`, CONCAT(co.nombres, ' ', co.apellidos) AS `Coach`, "
                    + "a.hora_entrada AS `Entrada`, a.hora_salida AS `Salida`, "
                    + "IF(a.hora_salida IS NULL, NULL, ROUND(TIMESTAMPDIFF(MINUTE, a.hora_entrada, a.hora_salida) / 60, 2)) AS `Horas` "
                    + "FROM asistencia_coach a JOIN coaches co ON co.id_coach = a.id_coach "
                    + "WHERE DATE(a.hora_entrada) BETWEEN ? AND ?");
            ArrayList<Object> p = new ArrayList<>();
            p.add(desde);
            p.add(hasta);
            if (Sesion.esCoach()) {
                sql.append(" AND a.id_coach = ?");
                p.add(Sesion.idCoach);
            } else {
                int pos = cmbCoach.getSelectedIndex();
                if (pos > 0 && pos < idsCoach.size()) {
                    sql.append(" AND a.id_coach = ?");
                    p.add(idsCoach.get(pos));
                }
            }
            sql.append(" ORDER BY a.hora_entrada DESC");
            DefaultTableModel m = Db.consultar(sql.toString(), p.toArray());
            tabla.setModel(m);
 
            double total = 0;
            for (int i = 0; i < m.getRowCount(); i++) {
                Object h = m.getValueAt(i, 4);
                if (h != null) {
                    total += ((Number) h).doubleValue();
                }
            }
            lblTotal.setText("Total de horas: " + String.format("%.2f", total));
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    private void marcarEntrada() {
        try {
            Object abiertas = Db.escalar("SELECT COUNT(*) FROM asistencia_coach "
                    + "WHERE id_coach = ? AND hora_salida IS NULL", Sesion.idCoach);
            if (((Number) abiertas).intValue() > 0) {
                Ui.error(this, "Ya tienes una entrada abierta. Marca tu salida primero.");
                return;
            }
            Db.ejecutar("INSERT INTO asistencia_coach(id_coach, hora_entrada) VALUES(?, NOW())", Sesion.idCoach);
            Ui.info(this, "Entrada registrada.");
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    private void marcarSalida() {
        try {
            int n = Db.ejecutar("UPDATE asistencia_coach SET hora_salida = NOW() "
                    + "WHERE id_coach = ? AND hora_salida IS NULL", Sesion.idCoach);
            if (n == 0) {
                Ui.error(this, "No tienes una entrada abierta. Marca tu entrada primero.");
                return;
            }
            Ui.info(this, "Salida registrada.");
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        lblTotal = new javax.swing.JLabel();
        cmbCoach = new javax.swing.JComboBox<>();
        lblCoach = new javax.swing.JLabel();
        lblNombre5 = new javax.swing.JLabel();
        btnFiltrar = new javax.swing.JButton();
        txtDesde = new javax.swing.JTextField();
        txtHasta = new javax.swing.JTextField();
        btnEntrada = new javax.swing.JButton();
        btnSalida = new javax.swing.JButton();
        lblNombre6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();

        setPreferredSize(new java.awt.Dimension(900, 400));
        setLayout(new java.awt.BorderLayout());

        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        pnlForm.setPreferredSize(new java.awt.Dimension(900, 250));
        pnlForm.setLayout(null);

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotal.setForeground(new java.awt.Color(73, 80, 87));
        lblTotal.setText("Total de horas: ");
        pnlForm.add(lblTotal);
        lblTotal.setBounds(550, 160, 260, 20);

        cmbCoach.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pnlForm.add(cmbCoach);
        cmbCoach.setBounds(20, 60, 230, 40);

        lblCoach.setForeground(new java.awt.Color(73, 80, 87));
        lblCoach.setText("Coach");
        pnlForm.add(lblCoach);
        lblCoach.setBounds(20, 30, 260, 16);

        lblNombre5.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre5.setText("Desde (AAAA-MM-DD)");
        pnlForm.add(lblNombre5);
        lblNombre5.setBounds(300, 30, 260, 16);

        btnFiltrar.setBackground(new java.awt.Color(255, 204, 51));
        btnFiltrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFiltrar.setText("Filtrar");
        pnlForm.add(btnFiltrar);
        btnFiltrar.setBounds(760, 60, 130, 40);

        txtDesde.setText("jTextField1");
        pnlForm.add(txtDesde);
        txtDesde.setBounds(300, 60, 180, 40);

        txtHasta.setText("jTextField1");
        pnlForm.add(txtHasta);
        txtHasta.setBounds(540, 60, 180, 40);

        btnEntrada.setBackground(new java.awt.Color(255, 204, 51));
        btnEntrada.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEntrada.setText("Marcar ENTRADA");
        pnlForm.add(btnEntrada);
        btnEntrada.setBounds(30, 140, 220, 50);

        btnSalida.setBackground(new java.awt.Color(0, 0, 0));
        btnSalida.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnSalida.setForeground(new java.awt.Color(255, 255, 255));
        btnSalida.setText("Marcar SALIDA");
        pnlForm.add(btnSalida);
        btnSalida.setBounds(300, 140, 220, 50);

        lblNombre6.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre6.setText("Hasta (AAAA-MM-DD)");
        pnlForm.add(lblNombre6);
        lblNombre6.setBounds(540, 26, 260, 20);

        add(pnlForm, java.awt.BorderLayout.PAGE_START);
        pnlForm.getAccessibleContext().setAccessibleName("");
        pnlForm.getAccessibleContext().setAccessibleDescription("");

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);

        getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEntrada;
    private javax.swing.JButton btnFiltrar;
    private javax.swing.JButton btnSalida;
    private javax.swing.JComboBox<String> cmbCoach;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCoach;
    private javax.swing.JLabel lblNombre5;
    private javax.swing.JLabel lblNombre6;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField txtDesde;
    private javax.swing.JTextField txtHasta;
    // End of variables declaration//GEN-END:variables
}
