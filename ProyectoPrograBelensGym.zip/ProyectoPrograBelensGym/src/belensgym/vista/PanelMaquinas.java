/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Db;
import belensgym.util.Estilo;
import belensgym.util.Ui;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
/**
 *
 * @author carlo
 */
public class PanelMaquinas extends javax.swing.JPanel implements Recargable {
 
    private Integer idSel = null;
    private byte[] fotoBytes = null;   // foto elegida y aún no guardada
 
    public PanelMaquinas() {
        initComponents();
        cmbCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"CARDIOVASCULAR", "FUERZA", "PESO_LIBRE", "OTRO"}));
        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"DISPONIBLE", "EN_MANTENIMIENTO", "FUERA_DE_SERVICIO"}));
        Estilo.tabla(tabla);
        Estilo.campo(txtNombre, txtMarca, txtSerie, txtAdquisicion);
        Estilo.primario(btnGuardar);
        Estilo.secundario(btnNueva);
        Estilo.secundario(btnFoto);
 
        // Recuadro de la foto
        lblFoto.setOpaque(true);
        lblFoto.setBackground(new Color(0xF8, 0xF9, 0xFA));
        lblFoto.setBorder(BorderFactory.createLineBorder(Estilo.BORDE));
        lblFoto.setHorizontalAlignment(SwingConstants.CENTER);
        lblFoto.setForeground(Estilo.GRIS);
        mostrarFoto(null);
 
        btnNueva.addActionListener(e -> nuevo());
        btnGuardar.addActionListener(e -> guardar());
        btnFoto.addActionListener(e -> elegirFoto());
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarSeleccion();
            }
        });
        recargar();
    }
 
    @Override
    public void recargar() {
        try {
            tabla.setModel(Db.consultar(
                    "SELECT id_maquina AS `ID`, nombre AS `Nombre`, categoria AS `Categoría`, marca AS `Marca`, "
                    + "serie AS `Serie`, fecha_adquisicion AS `Adquisición`, estado AS `Estado` "
                    + "FROM maquinas ORDER BY id_maquina DESC"));
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    /** Muestra la foto dentro del recuadro, ajustada a su tamaño; null = "Sin foto". */
    private void mostrarFoto(byte[] datos) {
        if (datos == null) {
            lblFoto.setIcon(null);
            lblFoto.setText("Sin foto");
            return;
        }
        try {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(datos));
            if (img == null) {
                lblFoto.setIcon(null);
                lblFoto.setText("Sin foto");
                return;
            }
            int w = Math.max(lblFoto.getWidth(), 140) - 4;
            int h = Math.max(lblFoto.getHeight(), 170) - 4;
            double escala = Math.min(1.0, Math.min((double) w / img.getWidth(), (double) h / img.getHeight()));
            int nw = Math.max(1, (int) (img.getWidth() * escala));
            int nh = Math.max(1, (int) (img.getHeight() * escala));
            lblFoto.setText("");
            lblFoto.setIcon(new ImageIcon(img.getScaledInstance(nw, nh, java.awt.Image.SCALE_SMOOTH)));
        } catch (java.io.IOException e) {
            lblFoto.setIcon(null);
            lblFoto.setText("Sin foto");
        }
    }
 
    /** Abre el selector de archivos, reduce la imagen (máx. 600 px) y la deja lista para guardar. */
    private void elegirFoto() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Imágenes (jpg, png)", "jpg", "jpeg", "png"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        try {
            File archivo = fc.getSelectedFile();
            BufferedImage img = ImageIO.read(archivo);
            if (img == null) {
                Ui.error(this, "El archivo no es una imagen válida.");
                return;
            }
            double escala = Math.min(1.0, 600.0 / Math.max(img.getWidth(), img.getHeight()));
            int ancho = Math.max(1, (int) (img.getWidth() * escala));
            int alto = Math.max(1, (int) (img.getHeight() * escala));
            BufferedImage chica = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_RGB);
            java.awt.Graphics2D g = chica.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, ancho, alto);
            g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,
                    java.awt.RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g.drawImage(img, 0, 0, ancho, alto, null);
            g.dispose();
            ByteArrayOutputStream salida = new ByteArrayOutputStream();
            ImageIO.write(chica, "jpg", salida);
            fotoBytes = salida.toByteArray();
            mostrarFoto(fotoBytes);
        } catch (java.io.IOException e) {
            Ui.error(this, "No se pudo leer la imagen.");
        }
    }
 
    private void cargarSeleccion() {
        if (tabla.getSelectedRow() < 0) {
            return;
        }
        idSel = Ui.id(tabla);
        txtNombre.setText(Ui.txt(tabla, 1));
        cmbCategoria.setSelectedItem(Ui.txt(tabla, 2));
        txtMarca.setText(Ui.txt(tabla, 3));
        txtSerie.setText(Ui.txt(tabla, 4));
        txtAdquisicion.setText(Ui.txt(tabla, 5));
        cmbEstado.setSelectedItem(Ui.txt(tabla, 6));
 
        fotoBytes = null;
        try {
            Object f = Db.escalar("SELECT foto FROM maquinas WHERE id_maquina = ?", idSel);
            mostrarFoto(f instanceof byte[] ? (byte[]) f : null);
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    private void nuevo() {
        idSel = null;
        txtNombre.setText("");
        txtMarca.setText("");
        txtSerie.setText("");
        txtAdquisicion.setText("");
        cmbCategoria.setSelectedIndex(0);
        cmbEstado.setSelectedItem("DISPONIBLE");
        fotoBytes = null;
        mostrarFoto(null);
        tabla.clearSelection();
        txtNombre.requestFocus();
    }
 
    private void guardar() {
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) {
            Ui.error(this, "El nombre de la máquina es obligatorio.");
            return;
        }
        java.sql.Date adq;
        try {
            adq = Ui.fecha(txtAdquisicion.getText());
        } catch (IllegalArgumentException e) {
            Ui.error(this, "Fecha inválida. Usa el formato AAAA-MM-DD.");
            return;
        }
        try {
            if (idSel == null) {
                Db.ejecutar("INSERT INTO maquinas(nombre, categoria, marca, serie, fecha_adquisicion, estado, foto) "
                        + "VALUES(?,?,?,?,?,?,?)", nombre, cmbCategoria.getSelectedItem(),
                        Ui.nul(txtMarca.getText()), Ui.nul(txtSerie.getText()), adq,
                        cmbEstado.getSelectedItem(), fotoBytes);
            } else {
                Db.ejecutar("UPDATE maquinas SET nombre=?, categoria=?, marca=?, serie=?, fecha_adquisicion=?, estado=? "
                        + "WHERE id_maquina=?", nombre, cmbCategoria.getSelectedItem(),
                        Ui.nul(txtMarca.getText()), Ui.nul(txtSerie.getText()), adq,
                        cmbEstado.getSelectedItem(), idSel);
                if (fotoBytes != null) {
                    // la foto solo se cambia si se eligió una nueva
                    Db.ejecutar("UPDATE maquinas SET foto=? WHERE id_maquina=?", fotoBytes, idSel);
                }
            }
            Ui.info(this, "Máquina guardada correctamente.");
            nuevo();
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        txtNombre = new javax.swing.JTextField();
        txtMarca = new javax.swing.JTextField();
        txtSerie = new javax.swing.JTextField();
        txtAdquisicion = new javax.swing.JTextField();
        cmbEstado = new javax.swing.JComboBox<>();
        btnNueva = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        lblFoto = new javax.swing.JLabel();
        btnFoto = new javax.swing.JButton();
        lblNombre = new javax.swing.JLabel();
        lblNombre1 = new javax.swing.JLabel();
        lblNombre2 = new javax.swing.JLabel();
        lblNombre3 = new javax.swing.JLabel();
        lblNombre5 = new javax.swing.JLabel();
        lblNombre6 = new javax.swing.JLabel();
        cmbCategoria = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();

        setLayout(new java.awt.BorderLayout());

        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        pnlForm.setPreferredSize(new java.awt.Dimension(1650, 350));
        pnlForm.setLayout(null);
        pnlForm.add(txtNombre);
        txtNombre.setBounds(20, 60, 250, 40);
        pnlForm.add(txtMarca);
        txtMarca.setBounds(680, 60, 210, 40);
        pnlForm.add(txtSerie);
        txtSerie.setBounds(20, 180, 250, 40);
        txtSerie.getAccessibleContext().setAccessibleName("");

        pnlForm.add(txtAdquisicion);
        txtAdquisicion.setBounds(350, 180, 250, 40);

        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pnlForm.add(cmbEstado);
        cmbEstado.setBounds(680, 180, 210, 40);

        btnNueva.setBackground(new java.awt.Color(0, 0, 0));
        btnNueva.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnNueva.setForeground(new java.awt.Color(255, 255, 255));
        btnNueva.setText("Nueva");
        pnlForm.add(btnNueva);
        btnNueva.setBounds(20, 260, 160, 40);

        btnGuardar.setBackground(new java.awt.Color(255, 204, 51));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnGuardar.setText("Guardar");
        pnlForm.add(btnGuardar);
        btnGuardar.setBounds(210, 260, 160, 40);

        lblFoto.setText("                               Sin foto");
        lblFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pnlForm.add(lblFoto);
        lblFoto.setBounds(970, 20, 250, 260);
        lblFoto.getAccessibleContext().setAccessibleDescription("");

        btnFoto.setBackground(new java.awt.Color(0, 0, 0));
        btnFoto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFoto.setForeground(new java.awt.Color(255, 255, 255));
        btnFoto.setText("Seleccionar foto");
        btnFoto.addActionListener(this::btnFotoActionPerformed);
        pnlForm.add(btnFoto);
        btnFoto.setBounds(1020, 290, 140, 40);

        lblNombre.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre.setText("Marca");
        pnlForm.add(lblNombre);
        lblNombre.setBounds(680, 30, 60, 16);

        lblNombre1.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre1.setText("Estado");
        pnlForm.add(lblNombre1);
        lblNombre1.setBounds(680, 150, 110, 20);

        lblNombre2.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre2.setText("Categoria");
        pnlForm.add(lblNombre2);
        lblNombre2.setBounds(350, 30, 80, 20);

        lblNombre3.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre3.setText("Nombre");
        pnlForm.add(lblNombre3);
        lblNombre3.setBounds(20, 30, 90, 30);

        lblNombre5.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre5.setText("Adquisicion (AAAA-MM-DD)");
        pnlForm.add(lblNombre5);
        lblNombre5.setBounds(350, 150, 240, 30);

        lblNombre6.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre6.setText("Serie");
        pnlForm.add(lblNombre6);
        lblNombre6.setBounds(20, 150, 170, 20);

        cmbCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pnlForm.add(cmbCategoria);
        cmbCategoria.setBounds(350, 60, 250, 40);

        add(pnlForm, java.awt.BorderLayout.PAGE_START);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnFotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFotoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFotoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFoto;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNueva;
    private javax.swing.JComboBox<String> cmbCategoria;
    private javax.swing.JComboBox<String> cmbEstado;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblNombre1;
    private javax.swing.JLabel lblNombre2;
    private javax.swing.JLabel lblNombre3;
    private javax.swing.JLabel lblNombre5;
    private javax.swing.JLabel lblNombre6;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField txtAdquisicion;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtSerie;
    // End of variables declaration//GEN-END:variables

    private void mostrarFoto(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
