/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Db;
import belensgym.util.Estilo;
import belensgym.util.Ui;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author carlo
 */
public class PanelReportes extends javax.swing.JPanel implements Recargable {
 
    private static final String[] NOMBRES = {
        "Clientes con membresía por vencer (7 días)",
        "Clientes activos sin membresía vigente",
        "Horas trabajadas por coach (por mes)",
        "Máquinas en mantenimiento o fuera de servicio",
        "Ingresos por mes",
        "Resumen de clientes (activos e inactivos)"
    };
    
    private static final String[] CONSULTAS = {
        // 0. Clientes con membresía por vencer
        "SELECT cliente AS `Cliente`, membresia AS `Membresía`, fecha_vencimiento AS `Vence`, "
        + "dias_restantes AS `Días restantes` FROM v_clientes_por_vencer ORDER BY dias_restantes",
        // 1. Clientes activos sin membresía vigente
        "SELECT c.id_cliente AS `ID`, CONCAT(c.nombres,' ',c.apellidos) AS `Cliente`, c.telefono AS `Teléfono` "
        + "FROM clientes c WHERE c.estado='ACTIVO' AND NOT EXISTS (SELECT 1 FROM membresias_cliente m "
        + "WHERE m.id_cliente = c.id_cliente AND m.estado='VIGENTE' AND m.fecha_vencimiento >= CURDATE()) "
        + "ORDER BY c.nombres",
        // 2. Horas trabajadas por coach
        "SELECT coach AS `Coach`, DATE_FORMAT(fecha, '%Y-%m') AS `Mes`, COUNT(*) AS `Jornadas`, "
        + "ROUND(SUM(horas), 2) AS `Horas totales` FROM v_horas_coach "
        + "GROUP BY id_coach, coach, DATE_FORMAT(fecha, '%Y-%m') ORDER BY `Mes` DESC, coach",
        // 3. Máquinas en mantenimiento o fuera de servicio
        "SELECT nombre AS `Máquina`, estado AS `Estado`, tipo AS `Tipo`, descripcion AS `Descripción`, "
        + "fecha_reporte AS `Reportado`, fecha_estimada_fin AS `Disponible aprox.` "
        + "FROM v_maquinas_en_mantenimiento ORDER BY fecha_reporte",
        // 4. Ingresos por mes
        "SELECT DATE_FORMAT(fecha_pago, '%Y-%m') AS `Mes`, COUNT(*) AS `Pagos`, SUM(monto) AS `Total (Q)` "
        + "FROM pagos GROUP BY DATE_FORMAT(fecha_pago, '%Y-%m') ORDER BY `Mes` DESC",
        // 5. Resumen de clientes
        "SELECT estado AS `Estado`, COUNT(*) AS `Total` FROM clientes GROUP BY estado"
    };


    /**
     * Creates new form PanelReportes
     */
     public PanelReportes() {
        initComponents();
        cmbReporte.setModel(new javax.swing.DefaultComboBoxModel<>(NOMBRES));
        Estilo.tabla(tabla);
        Estilo.primario(btnGenerar);
        Estilo.secundario(btnCsv);
        btnGenerar.addActionListener(e -> recargar());
        btnCsv.addActionListener(e -> Ui.exportarCsv(this, tabla));
        cmbReporte.addActionListener(e -> recargar());
        recargar();
    }
      @Override
    public void recargar() {
        try {
            DefaultTableModel m = Db.consultar(CONSULTAS[cmbReporte.getSelectedIndex()]);
            tabla.setModel(m);
            lblFilas.setText("Registros: " + m.getRowCount());
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        lblCliente = new javax.swing.JLabel();
        cmbReporte = new javax.swing.JComboBox<>();
        btnCsv = new javax.swing.JButton();
        btnGenerar = new javax.swing.JButton();
        lblFilas = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();

        setPreferredSize(new java.awt.Dimension(600, 627));
        setLayout(new java.awt.BorderLayout());

        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        pnlForm.setPreferredSize(new java.awt.Dimension(300, 130));
        pnlForm.setLayout(null);

        lblCliente.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCliente.setForeground(new java.awt.Color(73, 80, 87));
        lblCliente.setText("Reportes");
        pnlForm.add(lblCliente);
        lblCliente.setBounds(20, 20, 130, 20);

        cmbReporte.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbReporte.addActionListener(this::cmbReporteActionPerformed);
        pnlForm.add(cmbReporte);
        cmbReporte.setBounds(20, 40, 300, 40);

        btnCsv.setBackground(new java.awt.Color(255, 0, 0));
        btnCsv.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCsv.setForeground(new java.awt.Color(255, 255, 255));
        btnCsv.setText("Exportar CVS");
        pnlForm.add(btnCsv);
        btnCsv.setBounds(600, 40, 220, 40);

        btnGenerar.setBackground(new java.awt.Color(255, 204, 51));
        btnGenerar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnGenerar.setText("Asignar y cobrar");
        pnlForm.add(btnGenerar);
        btnGenerar.setBounds(350, 40, 230, 40);

        lblFilas.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFilas.setForeground(new java.awt.Color(73, 80, 87));
        lblFilas.setText("Registros:");
        pnlForm.add(lblFilas);
        lblFilas.setBounds(10, 100, 80, 30);

        add(pnlForm, java.awt.BorderLayout.NORTH);

        jScrollPane3.setPreferredSize(new java.awt.Dimension(300, 100));

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabla.setPreferredSize(new java.awt.Dimension(200, 80));
        jScrollPane3.setViewportView(tabla);

        add(jScrollPane3, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void cmbReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbReporteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbReporteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCsv;
    private javax.swing.JButton btnGenerar;
    private javax.swing.JComboBox<String> cmbReporte;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblCliente;
    private javax.swing.JLabel lblFilas;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
