/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Db;
import belensgym.util.Estilo;
import belensgym.util.Ui;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
/**
 *
 * @author carlo
 */
public final class PanelCoaches extends javax.swing.JPanel implements Recargable {
 
    private Integer idSel = null;
    private String usuarioSel = "";
    private byte[] fotoBytes = null;

    /**
     * Creates new form PanelCoaches
     */
    public PanelCoaches() {
        initComponents();
        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"ACTIVO", "INACTIVO"}));
        Estilo.tabla(tabla);
        Estilo.campo(txtNombres, txtApellidos, txtTelefono, txtEmail, txtEspecialidad, txtUsuario, txtPass);
        Estilo.primario(btnGuardar);
        Estilo.secundario(btnNuevo);
        Estilo.secundario(btnFoto);
 
        lblFoto.setOpaque(true);
        lblFoto.setBackground(new Color(0xF8, 0xF9, 0xFA));
        lblFoto.setBorder(BorderFactory.createLineBorder(Estilo.BORDE));
        lblFoto.setHorizontalAlignment(SwingConstants.CENTER);
        lblFoto.setForeground(Estilo.GRIS);
        mostrarFoto(null);
 
        btnNuevo.addActionListener(e -> nuevo());
        btnGuardar.addActionListener(e -> guardar());
        btnFoto.addActionListener(e -> elegirFoto());
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarSeleccion();
            }
        });
        recargar();
    }
    
    @Override
    public void recargar() {
        try {
            tabla.setModel(Db.consultar(
                    "SELECT c.id_coach AS `ID`, c.nombres AS `Nombres`, c.apellidos AS `Apellidos`, "
                    + "c.telefono AS `Teléfono`, c.email AS `Correo`, c.especialidad AS `Especialidad`, "
                    + "u.username AS `Usuario`, c.estado AS `Estado` FROM coaches c "
                    + "LEFT JOIN usuarios u ON u.id_usuario = c.id_usuario ORDER BY c.id_coach DESC"));
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    
    private void mostrarFoto(byte[] datos) {
        if (datos == null) {
            lblFoto.setIcon(null);
            lblFoto.setText("Sin foto");
            return;
        }
        int w = Math.max(lblFoto.getWidth(), 140) - 2;
        int h = Math.max(lblFoto.getHeight(), 170) - 2;
        ImageIcon original = new ImageIcon(datos);
        double escala = Math.min((double) w / original.getIconWidth(), (double) h / original.getIconHeight());
        int nw = Math.max(1, (int) (original.getIconWidth() * escala));
        int nh = Math.max(1, (int) (original.getIconHeight() * escala));
        lblFoto.setText("");
        lblFoto.setIcon(new ImageIcon(original.getImage().getScaledInstance(nw, nh, java.awt.Image.SCALE_SMOOTH)));
    }
 
    /** Abre el selector de archivos, reduce la imagen a 300 px de ancho y la deja lista para guardar. */
    private void elegirFoto() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Imágenes (jpg, png)", "jpg", "jpeg", "png"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        try {
            File archivo = fc.getSelectedFile();
            BufferedImage img = ImageIO.read(archivo);
            if (img == null) {
                Ui.error(this, "El archivo no es una imagen válida.");
                return;
            }
            int ancho = Math.min(300, img.getWidth());
            int alto = Math.max(1, img.getHeight() * ancho / img.getWidth());
            BufferedImage chica = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_RGB);
            java.awt.Graphics2D g = chica.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, ancho, alto);
            g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,
                    java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(img, 0, 0, ancho, alto, null);
            g.dispose();
            ByteArrayOutputStream salida = new ByteArrayOutputStream();
            ImageIO.write(chica, "jpg", salida);
            fotoBytes = salida.toByteArray();
            mostrarFoto(fotoBytes);
        } catch (java.io.IOException e) {
            Ui.error(this, "No se pudo leer la imagen.");
        }
    }
 
    private void cargarSeleccion() {
        if (tabla.getSelectedRow() < 0) {
            return;
        }
        idSel = Ui.id(tabla);
        txtNombres.setText(Ui.txt(tabla, 1));
        txtApellidos.setText(Ui.txt(tabla, 2));
        txtTelefono.setText(Ui.txt(tabla, 3));
        txtEmail.setText(Ui.txt(tabla, 4));
        txtEspecialidad.setText(Ui.txt(tabla, 5));
        usuarioSel = Ui.txt(tabla, 6);
        txtUsuario.setText(usuarioSel);
        txtUsuario.setEditable(usuarioSel.isEmpty());
        txtPass.setText("");
        cmbEstado.setSelectedItem(Ui.txt(tabla, 7));
 
        fotoBytes = null;
        try {
            Object f = Db.escalar("SELECT foto FROM coaches WHERE id_coach=?", idSel);
            mostrarFoto(f instanceof byte[] ? (byte[]) f : null);
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    private void nuevo() {
        idSel = null;
        usuarioSel = "";
        txtNombres.setText("");
        txtApellidos.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtEspecialidad.setText("");
        txtUsuario.setText("");
        txtUsuario.setEditable(true);
        txtPass.setText("");
        cmbEstado.setSelectedItem("ACTIVO");
        fotoBytes = null;
        mostrarFoto(null);
        tabla.clearSelection();
        txtNombres.requestFocus();
    }
 
    /** Crea el usuario con rol COACH y devuelve su id (o null si hubo un problema ya avisado). */
    private Integer crearUsuario(String user, String pass) throws SQLException {
        if (pass.isEmpty()) {
            Ui.error(this, "Escribe una contraseña para el usuario del coach.");
            return null;
        }
        Object existe = Db.escalar("SELECT COUNT(*) FROM usuarios WHERE username=?", user);
        if (((Number) existe).intValue() > 0) {
            Ui.error(this, "Ese nombre de usuario ya existe. Elige otro.");
            return null;
        }
        return Db.insertarId("INSERT INTO usuarios(username, password, id_rol) "
                + "VALUES(?, ?, (SELECT id_rol FROM roles WHERE nombre='COACH'))", user, Ui.sha256(pass));
    }
 
    private void guardar() {
        String nom = txtNombres.getText().trim();
        String ape = txtApellidos.getText().trim();
        if (nom.isEmpty() || ape.isEmpty()) {
            Ui.error(this, "Los nombres y apellidos son obligatorios.");
            return;
        }
        String user = txtUsuario.getText().trim();
        String pass = txtPass.getText();
        String estado = (String) cmbEstado.getSelectedItem();
        try {
            if (idSel == null) {
                Integer idUsr = null;
                if (!user.isEmpty()) {
                    idUsr = crearUsuario(user, pass);
                    if (idUsr == null) {
                        return;
                    }
                }
                Db.ejecutar("INSERT INTO coaches(id_usuario, nombres, apellidos, telefono, email, especialidad, estado, foto) "
                        + "VALUES(?,?,?,?,?,?,?,?)", idUsr, nom, ape, Ui.nul(txtTelefono.getText()),
                        Ui.nul(txtEmail.getText()), Ui.nul(txtEspecialidad.getText()), estado, fotoBytes);
            } else {
                Db.ejecutar("UPDATE coaches SET nombres=?, apellidos=?, telefono=?, email=?, especialidad=?, estado=? "
                        + "WHERE id_coach=?", nom, ape, Ui.nul(txtTelefono.getText()), Ui.nul(txtEmail.getText()),
                        Ui.nul(txtEspecialidad.getText()), estado, idSel);
                if (fotoBytes != null) {
                    Db.ejecutar("UPDATE coaches SET foto=? WHERE id_coach=?", fotoBytes, idSel);
                }
                if (!usuarioSel.isEmpty()) {
                    // El usuario se activa o desactiva junto con el coach
                    Db.ejecutar("UPDATE usuarios SET activo=? WHERE id_usuario=(SELECT id_usuario FROM coaches WHERE id_coach=?)",
                            "ACTIVO".equals(estado), idSel);
                    if (!pass.isEmpty()) {
                        Db.ejecutar("UPDATE usuarios SET password=? WHERE id_usuario=(SELECT id_usuario FROM coaches WHERE id_coach=?)",
                                Ui.sha256(pass), idSel);
                    }
                } else if (!user.isEmpty()) {
                    Integer idUsr = crearUsuario(user, pass);
                    if (idUsr == null) {
                        return;
                    }
                    Db.ejecutar("UPDATE coaches SET id_usuario=? WHERE id_coach=?", idUsr, idSel);
                }
            }
            Ui.info(this, "Coach guardado correctamente.");
            nuevo();
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        txtNombres = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtEspecialidad = new javax.swing.JTextField();
        cmbEstado = new javax.swing.JComboBox<>();
        txtUsuario = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        lblFoto = new javax.swing.JLabel();
        btnFoto = new javax.swing.JButton();
        lblNombre = new javax.swing.JLabel();
        lblNombre1 = new javax.swing.JLabel();
        lblNombre2 = new javax.swing.JLabel();
        lblNombre3 = new javax.swing.JLabel();
        lblNombre4 = new javax.swing.JLabel();
        lblNombre5 = new javax.swing.JLabel();
        lblNombre6 = new javax.swing.JLabel();
        lblNombre7 = new javax.swing.JLabel();
        txtPass = new javax.swing.JPasswordField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();

        setLayout(new java.awt.BorderLayout());

        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        pnlForm.setPreferredSize(new java.awt.Dimension(1650, 380));
        pnlForm.setLayout(null);

        txtNombres.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtNombres);
        txtNombres.setBounds(20, 40, 250, 40);

        txtApellidos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtApellidos);
        txtApellidos.setBounds(330, 40, 250, 40);

        txtTelefono.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtTelefono);
        txtTelefono.setBounds(660, 40, 210, 40);

        txtEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtEmail);
        txtEmail.setBounds(20, 140, 250, 40);
        txtEmail.getAccessibleContext().setAccessibleName("");

        txtEspecialidad.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtEspecialidad);
        txtEspecialidad.setBounds(330, 140, 250, 40);

        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pnlForm.add(cmbEstado);
        cmbEstado.setBounds(660, 140, 180, 40);

        txtUsuario.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtUsuario);
        txtUsuario.setBounds(20, 230, 250, 40);

        btnNuevo.setBackground(new java.awt.Color(0, 0, 0));
        btnNuevo.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(255, 255, 255));
        btnNuevo.setText("Nuevo");
        pnlForm.add(btnNuevo);
        btnNuevo.setBounds(20, 300, 160, 40);

        btnGuardar.setBackground(new java.awt.Color(255, 204, 51));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnGuardar.setText("Guardar");
        pnlForm.add(btnGuardar);
        btnGuardar.setBounds(200, 300, 160, 40);

        lblFoto.setText("                                 Sin foto");
        lblFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pnlForm.add(lblFoto);
        lblFoto.setBounds(970, 20, 250, 260);

        btnFoto.setBackground(new java.awt.Color(0, 0, 0));
        btnFoto.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnFoto.setForeground(new java.awt.Color(255, 255, 255));
        btnFoto.setText("Seleccionar foto");
        btnFoto.addActionListener(this::btnFotoActionPerformed);
        pnlForm.add(btnFoto);
        btnFoto.setBounds(1030, 290, 140, 40);

        lblNombre.setBackground(new java.awt.Color(204, 204, 204));
        lblNombre.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre.setText("Telefono");
        pnlForm.add(lblNombre);
        lblNombre.setBounds(660, 20, 60, 16);

        lblNombre1.setBackground(new java.awt.Color(204, 204, 204));
        lblNombre1.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre1.setText("Estado");
        pnlForm.add(lblNombre1);
        lblNombre1.setBounds(660, 120, 110, 20);

        lblNombre2.setBackground(new java.awt.Color(204, 204, 204));
        lblNombre2.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre2.setText("Apellidos");
        pnlForm.add(lblNombre2);
        lblNombre2.setBounds(330, 20, 60, 16);

        lblNombre3.setBackground(new java.awt.Color(204, 204, 204));
        lblNombre3.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre3.setText("Nombre");
        pnlForm.add(lblNombre3);
        lblNombre3.setBounds(20, 20, 120, 10);

        lblNombre4.setBackground(new java.awt.Color(204, 204, 204));
        lblNombre4.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre4.setText("Contraseña");
        pnlForm.add(lblNombre4);
        lblNombre4.setBounds(330, 200, 130, 20);

        lblNombre5.setBackground(new java.awt.Color(204, 204, 204));
        lblNombre5.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre5.setText("Especialidad");
        pnlForm.add(lblNombre5);
        lblNombre5.setBounds(330, 114, 110, 16);

        lblNombre6.setBackground(new java.awt.Color(204, 204, 204));
        lblNombre6.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre6.setText("Correo");
        pnlForm.add(lblNombre6);
        lblNombre6.setBounds(20, 120, 170, 10);

        lblNombre7.setBackground(new java.awt.Color(204, 204, 204));
        lblNombre7.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre7.setText("Usuario de acceso");
        pnlForm.add(lblNombre7);
        lblNombre7.setBounds(20, 200, 130, 20);

        txtPass.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtPass);
        txtPass.setBounds(330, 230, 240, 40);

        add(pnlForm, java.awt.BorderLayout.NORTH);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnFotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFotoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFotoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFoto;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cmbEstado;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblNombre1;
    private javax.swing.JLabel lblNombre2;
    private javax.swing.JLabel lblNombre3;
    private javax.swing.JLabel lblNombre4;
    private javax.swing.JLabel lblNombre5;
    private javax.swing.JLabel lblNombre6;
    private javax.swing.JLabel lblNombre7;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEspecialidad;
    private javax.swing.JTextField txtNombres;
    private javax.swing.JPasswordField txtPass;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables

    private void mostrarFoto(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
