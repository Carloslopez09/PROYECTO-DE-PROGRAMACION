/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Conexion;
import belensgym.util.Db;
import belensgym.util.Estilo;
import belensgym.util.Sesion;
import belensgym.util.Ui;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
/**
 *
 * @author carlo
 */
public class PanelMembresias extends javax.swing.JPanel implements Recargable {
 
    public PanelMembresias() {
        initComponents();
        cmbMetodo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"EFECTIVO", "TARJETA", "TRANSFERENCIA"}));
        txtInicio.setText(LocalDate.now().toString());
        Estilo.tabla(tablaMem);
        Estilo.tabla(tablaPagos);
        Estilo.campo(txtInicio);
        Estilo.primario(btnAsignar);
        Estilo.peligro(btnCancelar);
 
        btnAsignar.addActionListener(e -> asignar());
        btnCancelar.addActionListener(e -> cancelar());
        recargar();
    }
    
    @Override
    public void recargar() {
        try {
            // Marca como vencidas las membresías cuya fecha ya pasó
            Db.ejecutar("UPDATE membresias_cliente SET estado='VENCIDA' "
                    + "WHERE estado='VIGENTE' AND fecha_vencimiento < CURDATE()");
            Ui.cargarCombo(cmbCliente, "SELECT id_cliente, CONCAT(nombres,' ',apellidos) FROM clientes "
                    + "WHERE estado='ACTIVO' ORDER BY nombres");
            Ui.cargarCombo(cmbTipo, "SELECT id_tipo, CONCAT(nombre,' - Q',precio,' (',duracion_dias,' días)') "
                    + "FROM tipos_membresia ORDER BY duracion_dias");
            tablaMem.setModel(Db.consultar(
                    "SELECT m.id_membresia AS `ID`, CONCAT(c.nombres,' ',c.apellidos) AS `Cliente`, "
                    + "t.nombre AS `Membresía`, m.fecha_inicio AS `Inicio`, m.fecha_vencimiento AS `Vence`, "
                    + "m.estado AS `Estado` FROM membresias_cliente m "
                    + "JOIN clientes c ON c.id_cliente = m.id_cliente "
                    + "JOIN tipos_membresia t ON t.id_tipo = m.id_tipo ORDER BY m.id_membresia DESC"));
            tablaPagos.setModel(Db.consultar(
                    "SELECT p.id_pago AS `ID`, CONCAT(c.nombres,' ',c.apellidos) AS `Cliente`, "
                    + "t.nombre AS `Membresía`, p.fecha_pago AS `Fecha`, p.monto AS `Monto (Q)`, "
                    + "p.metodo_pago AS `Método` FROM pagos p "
                    + "JOIN membresias_cliente m ON m.id_membresia = p.id_membresia "
                    + "JOIN clientes c ON c.id_cliente = m.id_cliente "
                    + "JOIN tipos_membresia t ON t.id_tipo = m.id_tipo ORDER BY p.id_pago DESC"));
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    
     private void asignar() {
        Ui.Item cli = Ui.item(cmbCliente);
        Ui.Item tipo = Ui.item(cmbTipo);
        if (cli == null || tipo == null) {
            Ui.error(this, "Selecciona un cliente y un tipo de membresía.");
            return;
        }
        java.sql.Date inicio;
        try {
            inicio = Ui.fecha(txtInicio.getText());
            if (inicio == null) {
                throw new IllegalArgumentException();
            }
        } catch (IllegalArgumentException e) {
            Ui.error(this, "Fecha de inicio inválida. Usa el formato AAAA-MM-DD.");
            return;
        }
        
         try {
            Object vigentes = Db.escalar("SELECT COUNT(*) FROM membresias_cliente WHERE id_cliente=? "
                    + "AND estado='VIGENTE' AND fecha_vencimiento >= CURDATE()", cli.id);
            if (((Number) vigentes).intValue() > 0
                    && !Ui.confirmar(this, "Este cliente ya tiene una membresía vigente. ¿Asignar otra de todos modos?")) {
                return;
            }
        } catch (SQLException e) {
            Ui.error(this, e);
            return;
        }
        
        try (Connection cn = Conexion.getConexion()) {
            cn.setAutoCommit(false);
            try {
                int dias = 0;
                double precio = 0;
                try (PreparedStatement ps = cn.prepareStatement(
                        "SELECT duracion_dias, precio FROM tipos_membresia WHERE id_tipo=?")) {
                    ps.setInt(1, tipo.id);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        dias = rs.getInt(1);
                        precio = rs.getDouble(2);
                    }
                }
 
                java.sql.Date vence = java.sql.Date.valueOf(inicio.toLocalDate().plusDays(dias));
                int idMem = 0;
                try (PreparedStatement ps = cn.prepareStatement(
                        "INSERT INTO membresias_cliente(id_cliente, id_tipo, fecha_inicio, fecha_vencimiento) "
                        + "VALUES(?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, cli.id);
                    ps.setInt(2, tipo.id);
                    ps.setDate(3, inicio);
                    ps.setDate(4, vence);
                    ps.executeUpdate();
                    try (ResultSet k = ps.getGeneratedKeys()) {
                        k.next();
                        idMem = k.getInt(1);
                    }
                }
                try (PreparedStatement ps = cn.prepareStatement(
                        "INSERT INTO pagos(id_membresia, id_usuario, monto, metodo_pago) VALUES(?,?,?,?)")) {
                    ps.setInt(1, idMem);
                    ps.setInt(2, Sesion.idUsuario);
                    ps.setDouble(3, precio);
                    ps.setString(4, (String) cmbMetodo.getSelectedItem());
                    ps.executeUpdate();
                }
                cn.commit();
                Ui.info(this, "Membresía asignada. Vence el " + vence + ". Monto cobrado: Q" + precio);
            } catch (SQLException e) {
                cn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            Ui.error(this, e);
        }
        recargar();
    }
     
     private void cancelar() {
        Integer id = Ui.id(tablaMem);
        if (id == null) {
            Ui.error(this, "Selecciona una membresía de la tabla.");
            return;
        }
        if (!Ui.confirmar(this, "¿Cancelar la membresía seleccionada?")) {
            return;
        }
        try {
            Db.ejecutar("UPDATE membresias_cliente SET estado='CANCELADA' WHERE id_membresia=?", id);
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        lblInicio = new javax.swing.JLabel();
        lblPago = new javax.swing.JLabel();
        lblMem = new javax.swing.JLabel();
        lblCliente = new javax.swing.JLabel();
        cmbMetodo = new javax.swing.JComboBox<>();
        cmbTipo = new javax.swing.JComboBox<>();
        cmbCliente = new javax.swing.JComboBox<>();
        txtInicio = new javax.swing.JTextField();
        btnCancelar = new javax.swing.JButton();
        btnAsignar = new javax.swing.JButton();
        split = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaMem = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaPagos = new javax.swing.JTable();

        setLayout(new java.awt.BorderLayout());

        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        pnlForm.setPreferredSize(new java.awt.Dimension(900, 200));
        pnlForm.setLayout(null);

        lblInicio.setBackground(new java.awt.Color(204, 204, 204));
        lblInicio.setForeground(new java.awt.Color(73, 80, 87));
        lblInicio.setText("Inicio");
        pnlForm.add(lblInicio);
        lblInicio.setBounds(870, 30, 130, 20);

        lblPago.setBackground(new java.awt.Color(204, 204, 204));
        lblPago.setForeground(new java.awt.Color(73, 80, 87));
        lblPago.setText("Metodo de pago");
        pnlForm.add(lblPago);
        lblPago.setBounds(40, 110, 130, 20);

        lblMem.setBackground(new java.awt.Color(204, 204, 204));
        lblMem.setForeground(new java.awt.Color(73, 80, 87));
        lblMem.setText("Tipo de membresia");
        pnlForm.add(lblMem);
        lblMem.setBounds(460, 30, 160, 20);

        lblCliente.setBackground(new java.awt.Color(204, 204, 204));
        lblCliente.setForeground(new java.awt.Color(73, 80, 87));
        lblCliente.setText("Cliente");
        pnlForm.add(lblCliente);
        lblCliente.setBounds(40, 30, 130, 20);

        cmbMetodo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pnlForm.add(cmbMetodo);
        cmbMetodo.setBounds(40, 130, 240, 40);

        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Membredia sesion (Q20)", "Membraesia Basico (Q300)", "Membresia Premun (Q350)", "Mmnresia Elite (Q1000)" }));
        cmbTipo.addActionListener(this::cmbTipoActionPerformed);
        pnlForm.add(cmbTipo);
        cmbTipo.setBounds(460, 50, 300, 40);

        cmbCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbCliente.addActionListener(this::cmbClienteActionPerformed);
        pnlForm.add(cmbCliente);
        cmbCliente.setBounds(40, 50, 300, 40);

        txtInicio.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtInicio.addActionListener(this::txtInicioActionPerformed);
        pnlForm.add(txtInicio);
        txtInicio.setBounds(870, 50, 150, 40);

        btnCancelar.setBackground(new java.awt.Color(255, 0, 0));
        btnCancelar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelar.setText("Cancelar membresia");
        pnlForm.add(btnCancelar);
        btnCancelar.setBounds(590, 130, 220, 40);

        btnAsignar.setBackground(new java.awt.Color(255, 204, 51));
        btnAsignar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnAsignar.setText("Asignar y cobrar");
        pnlForm.add(btnAsignar);
        btnAsignar.setBounds(340, 130, 230, 40);

        add(pnlForm, java.awt.BorderLayout.NORTH);

        split.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        split.setDividerLocation(250);
        split.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        split.setResizeWeight(0.5);
        split.setToolTipText("");
        split.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder("Membresias"));

        tablaMem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaMem.setPreferredSize(new java.awt.Dimension(200, 80));
        jScrollPane1.setViewportView(tablaMem);

        split.setTopComponent(jScrollPane1);

        jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder("Historial Pagos"));

        tablaPagos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tablaPagos);

        split.setBottomComponent(jScrollPane2);

        add(split, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void cmbClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbClienteActionPerformed

    private void txtInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtInicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtInicioActionPerformed

    private void cmbTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbTipoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAsignar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JComboBox<String> cmbCliente;
    private javax.swing.JComboBox<String> cmbMetodo;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCliente;
    private javax.swing.JLabel lblInicio;
    private javax.swing.JLabel lblMem;
    private javax.swing.JLabel lblPago;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JSplitPane split;
    private javax.swing.JTable tablaMem;
    private javax.swing.JTable tablaPagos;
    private javax.swing.JTextField txtInicio;
    // End of variables declaration//GEN-END:variables
}
