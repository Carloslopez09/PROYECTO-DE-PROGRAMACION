/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Db;
import belensgym.util.Estilo;
import belensgym.util.Ui;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;

/**
 *
 * @author carlo
 */
public class PanelClientes extends javax.swing.JPanel implements Recargable {
 
    private Integer idSel = null;
    /**
     * Creates new form PanelClientess
     */
    public PanelClientes() {
        initComponents();
        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"ACTIVO", "INACTIVO"}));
        Estilo.tabla(tabla);
        Estilo.campo(txtNombres, txtApellidos, txtTelefono, txtEmail, txtDireccion, txtNacimiento, txtBuscar);
        Estilo.primario(btnGuardar);
        Estilo.secundario(btnNuevo);
        Estilo.secundario(btnVisita);
        Estilo.peligro(btnBaja);
        
        btnNuevo.addActionListener(e -> nuevo());
        btnGuardar.addActionListener(e -> guardar());
        btnBaja.addActionListener(e -> darDeBaja());
        btnVisita.addActionListener(e -> registrarVisita());
        txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                recargar();
            }
        });
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarSeleccion();
            }
        });
        recargar();
    }
    
    @Override
    public void recargar() {
        try {
            String b = "%" + txtBuscar.getText().trim() + "%";
            tabla.setModel(Db.consultar(
                    "SELECT id_cliente AS `ID`, nombres AS `Nombres`, apellidos AS `Apellidos`, "
                    + "telefono AS `Teléfono`, email AS `Correo`, direccion AS `Dirección`, "
                    + "fecha_nacimiento AS `Nacimiento`, estado AS `Estado` "
                    + "FROM clientes WHERE CONCAT(nombres, ' ', apellidos) LIKE ? OR telefono LIKE ? "
                    + "ORDER BY id_cliente DESC", b, b));
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    
    private void cargarSeleccion() {
        if (tabla.getSelectedRow() < 0) {
            return;
        }
        idSel = Ui.id(tabla);
        txtNombres.setText(Ui.txt(tabla, 1));
        txtApellidos.setText(Ui.txt(tabla, 2));
        txtTelefono.setText(Ui.txt(tabla, 3));
        txtEmail.setText(Ui.txt(tabla, 4));
        txtDireccion.setText(Ui.txt(tabla, 5));
        txtNacimiento.setText(Ui.txt(tabla, 6));
        cmbEstado.setSelectedItem(Ui.txt(tabla, 7));
    }
 
    private void nuevo() {
        idSel = null;
        txtNombres.setText("");
        txtApellidos.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtDireccion.setText("");
        txtNacimiento.setText("");
        cmbEstado.setSelectedItem("ACTIVO");
        tabla.clearSelection();
        txtNombres.requestFocus();
    }
    
    private void guardar() {
        String nom = txtNombres.getText().trim();
        String ape = txtApellidos.getText().trim();
        if (nom.isEmpty() || ape.isEmpty()) {
            Ui.error(this, "Los nombres y apellidos son obligatorios.");
            return;
        }
        java.sql.Date nac;
        try {
            nac = Ui.fecha(txtNacimiento.getText());
        } catch (IllegalArgumentException e) {
            Ui.error(this, "Fecha de nacimiento inválida. Usa el formato AAAA-MM-DD.");
            return;
        }
        String estado = (String) cmbEstado.getSelectedItem();
        try {
            if (idSel == null) {
                Db.ejecutar("INSERT INTO clientes(nombres, apellidos, telefono, email, direccion, "
                        + "fecha_nacimiento, estado) VALUES(?,?,?,?,?,?,?)",
                        nom, ape, Ui.nul(txtTelefono.getText()), Ui.nul(txtEmail.getText()),
                        Ui.nul(txtDireccion.getText()), nac, estado);
            } else {
                Db.ejecutar("UPDATE clientes SET nombres=?, apellidos=?, telefono=?, email=?, direccion=?, "
                        + "fecha_nacimiento=?, estado=? WHERE id_cliente=?",
                        nom, ape, Ui.nul(txtTelefono.getText()), Ui.nul(txtEmail.getText()),
                        Ui.nul(txtDireccion.getText()), nac, estado, idSel);
            }
            Ui.info(this, "Cliente guardado correctamente.");
            nuevo();
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    
    private void darDeBaja() {
        if (idSel == null) {
            Ui.error(this, "Selecciona un cliente de la tabla.");
            return;
        }
        if (!Ui.confirmar(this, "¿Dar de baja al cliente? Se cancelarán sus membresías vigentes.")) {
            return;
        }
        try {
            Db.ejecutar("UPDATE clientes SET estado='INACTIVO' WHERE id_cliente=?", idSel);
            Db.ejecutar("UPDATE membresias_cliente SET estado='CANCELADA' WHERE id_cliente=? AND estado='VIGENTE'", idSel);
            nuevo();
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    
     private void registrarVisita() {
        if (idSel == null) {
            Ui.error(this, "Selecciona un cliente de la tabla.");
            return;
        }
        try {
            Object n = Db.escalar("SELECT COUNT(*) FROM membresias_cliente WHERE id_cliente=? "
                    + "AND estado='VIGENTE' AND fecha_vencimiento >= CURDATE()", idSel);
            if (((Number) n).intValue() == 0) {
                Ui.error(this, "El cliente no tiene una membresía vigente. No se registró la visita.");
                return;
            }
            Db.ejecutar("INSERT INTO asistencia_cliente(id_cliente) VALUES(?)", idSel);
            Ui.info(this, "Visita registrada.");
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        lblTelefono = new javax.swing.JLabel();
        lblNacimiento = new javax.swing.JLabel();
        lblApellidos = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblCorreo = new javax.swing.JLabel();
        lblDireccion = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        txtBuscar = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        txtNombres = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        cmbEstado = new javax.swing.JComboBox<>();
        lblNacimiento1 = new javax.swing.JLabel();
        btnVisita = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnBaja = new javax.swing.JButton();
        lblDireccion1 = new javax.swing.JLabel();
        txtNacimiento = new javax.swing.JTextField();
        JTable = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();

        setPreferredSize(new java.awt.Dimension(10000, 682));
        setLayout(new java.awt.BorderLayout());

        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        pnlForm.setPreferredSize(new java.awt.Dimension(1000, 280));

        lblTelefono.setForeground(new java.awt.Color(73, 80, 87));
        lblTelefono.setText("Telefono");

        lblNacimiento.setBackground(new java.awt.Color(204, 204, 204));
        lblNacimiento.setForeground(new java.awt.Color(73, 80, 87));
        lblNacimiento.setText("Estado");

        lblApellidos.setForeground(new java.awt.Color(73, 80, 87));
        lblApellidos.setText("Apellidos");

        lblNombre.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre.setText("Nombre");

        lblCorreo.setForeground(new java.awt.Color(73, 80, 87));
        lblCorreo.setText("Correo");

        lblDireccion.setForeground(new java.awt.Color(73, 80, 87));
        lblDireccion.setText("Buscar:");

        txtTelefono.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtBuscar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtApellidos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtNombres.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtDireccion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        cmbEstado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ACTIVO", "INCATIVO" }));

        lblNacimiento1.setForeground(new java.awt.Color(73, 80, 87));
        lblNacimiento1.setText("Nacimiento  (AAAA-MM-DD)");

        btnVisita.setBackground(new java.awt.Color(255, 204, 102));
        btnVisita.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnVisita.setText("Registrar Visita");
        btnVisita.addActionListener(this::btnVisitaActionPerformed);

        btnNuevo.setBackground(new java.awt.Color(0, 0, 0));
        btnNuevo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(255, 255, 255));
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(this::btnNuevoActionPerformed);

        btnGuardar.setBackground(new java.awt.Color(255, 204, 51));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);

        btnBaja.setBackground(new java.awt.Color(255, 51, 51));
        btnBaja.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBaja.setForeground(new java.awt.Color(255, 255, 255));
        btnBaja.setText("Dar De Baja");
        btnBaja.addActionListener(this::btnBajaActionPerformed);

        lblDireccion1.setForeground(new java.awt.Color(73, 80, 87));
        lblDireccion1.setText("Direccion");

        txtNacimiento.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout pnlFormLayout = new javax.swing.GroupLayout(pnlForm);
        pnlForm.setLayout(pnlFormLayout);
        pnlFormLayout.setHorizontalGroup(
            pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFormLayout.createSequentialGroup()
                        .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(144, 144, 144)
                        .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(108, 108, 108)
                        .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlFormLayout.createSequentialGroup()
                        .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlFormLayout.createSequentialGroup()
                                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(147, 147, 147)
                                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblDireccion1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(108, 108, 108)
                                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblNacimiento1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlFormLayout.createSequentialGroup()
                                        .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(pnlFormLayout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(lblDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(pnlFormLayout.createSequentialGroup()
                                                .addComponent(txtNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                                                .addComponent(lblNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(80, 80, 80))))
                            .addGroup(pnlFormLayout.createSequentialGroup()
                                .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnVisita, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBaja, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(66, 66, 66))))
        );
        pnlFormLayout.setVerticalGroup(
            pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblApellidos)
                        .addComponent(lblNombre))
                    .addComponent(lblTelefono, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlFormLayout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNacimiento))
                        .addContainerGap())
                    .addGroup(pnlFormLayout.createSequentialGroup()
                        .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnlFormLayout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblDireccion1)
                                    .addComponent(lblNacimiento1)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlFormLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(lblCorreo)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlFormLayout.createSequentialGroup()
                                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(116, 116, 116))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlFormLayout.createSequentialGroup()
                                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnVisita, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnBaja, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblDireccion)
                                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(35, 35, 35))))))
        );

        add(pnlForm, java.awt.BorderLayout.PAGE_START);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombres", "Apellidos", "Telefono", "Correo", "Direccion", "Nacimiento", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        JTable.setViewportView(tabla);

        add(JTable, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnBajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBajaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBajaActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnVisitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVisitaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnVisitaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane JTable;
    private javax.swing.JButton btnBaja;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnVisita;
    private javax.swing.JComboBox<String> cmbEstado;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblCorreo;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblDireccion1;
    private javax.swing.JLabel lblNacimiento;
    private javax.swing.JLabel lblNacimiento1;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNacimiento;
    private javax.swing.JTextField txtNombres;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
