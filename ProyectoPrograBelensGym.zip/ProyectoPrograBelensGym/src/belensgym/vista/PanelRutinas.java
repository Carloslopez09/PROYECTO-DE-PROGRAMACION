/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Db;
import belensgym.util.Estilo;
import belensgym.util.Sesion;
import belensgym.util.Ui;
import java.awt.Desktop;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author carlo
 */
public class PanelRutinas extends javax.swing.JPanel implements Recargable {

    private static final long MAX_BYTES = 5L * 1024 * 1024;   // 5 MB por archivo

    public PanelRutinas() {
        initComponents();
        Estilo.tabla(tabla);
        Estilo.campo(txtNombre);
        Estilo.primario(btnSubir);
        Estilo.secundario(btnAbrir);
        Estilo.secundario(btnEliminar);

        btnSubir.addActionListener(e -> subir());
        btnAbrir.addActionListener(e -> abrir());
        btnEliminar.addActionListener(e -> eliminar());
        // Doble clic sobre una fila = abrir el archivo
        tabla.addMouseListener(new MouseAdapter() {
                @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    abrir();
                }
            }
        });
        recargar();
    }
    @Override
    public void recargar() {
        try {
            tabla.setModel(Db.consultar(
                    "SELECT r.id_rutina AS ID, "
                    + "r.nombre AS Rutina, "
                    + "r.nombre_archivo AS Archivo, "
                    + "ROUND(LENGTH(r.archivo) / 1024) AS `Tamaño (KB)`, "
                    + "u.username AS `Subido por`, "
                    + "DATE_FORMAT(r.fecha, '%Y-%m-%d %H:%i') AS Fecha "
                    + "FROM rutinas r "
                    + "JOIN usuarios u ON u.id_usuario = r.id_usuario "
                    + "ORDER BY r.id_rutina DESC"
            ));
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    private void subir() {
        JFileChooser fc = new JFileChooser();
        fc.setAcceptAllFileFilterUsed(false);
        fc.setFileFilter(new FileNameExtensionFilter(
                "Archivos de Excel (xlsx, xls, xlsm, csv)", "xlsx", "xls", "xlsm", "csv"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File archivo = fc.getSelectedFile();
        if (archivo.length() > MAX_BYTES) {
            Ui.error(this, "El archivo pesa más de 5 MB. Elige uno más pequeño.");
            return;
        }
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) {
            nombre = quitarExtension(archivo.getName());
        }
        try {
            byte[] datos = Files.readAllBytes(archivo.toPath());
            Db.ejecutar("INSERT INTO rutinas(nombre, nombre_archivo, archivo, id_usuario) VALUES(?,?,?,?)",
                    nombre, archivo.getName(), datos, Sesion.idUsuario);
            txtNombre.setText("");
            Ui.info(this, "Rutina subida correctamente.");
            recargar();
        } catch (IOException e) {
            Ui.error(this, "No se pudo leer el archivo.");
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    
    private void abrir() {
        Integer id = Ui.id(tabla);
        if (id == null) {
            Ui.error(this, "Selecciona una rutina de la tabla.");
            return;
        }
        try {
            Object datos = Db.escalar("SELECT archivo FROM rutinas WHERE id_rutina = ?", id);
            if (!(datos instanceof byte[])) {
                Ui.error(this, "No se encontró el archivo.");
                return;
            }
            Path carpeta = Files.createTempDirectory("belensgym_");
            carpeta.toFile().deleteOnExit();
            Path destino = carpeta.resolve(limpiar(Ui.txt(tabla, 2)));
            Files.write(destino, (byte[]) datos);
            destino.toFile().deleteOnExit();
            if (!Desktop.isDesktopSupported()) {
                Ui.error(this, "Este equipo no permite abrir archivos desde el programa.");
                return;
            }
            Desktop.getDesktop().open(destino.toFile());
        } catch (IOException | SQLException e) {
            Ui.error(this, "No se pudo abrir el archivo:\n" + e.getMessage());
        }
    }

    /** El administrador elimina cualquier rutina; los demás, solo las que subieron ellos. */
    private void eliminar() {
        Integer id = Ui.id(tabla);
        if (id == null) {
            Ui.error(this, "Selecciona una rutina de la tabla.");
            return;
        }
        try {
            Object dueno = Db.escalar("SELECT id_usuario FROM rutinas WHERE id_rutina = ?", id);
            boolean propia = dueno != null && ((Number) dueno).intValue() == Sesion.idUsuario;
            if (!Sesion.esAdmin() && !propia) {
                Ui.error(this, "Solo puedes eliminar las rutinas que subiste tú.");
                return;
            }
            if (!Ui.confirmar(this, "¿Eliminar la rutina seleccionada?")) {
                return;
            }
            Db.ejecutar("DELETE FROM rutinas WHERE id_rutina = ?", id);
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }

    private static String quitarExtension(String nombre) {
        int i = nombre.lastIndexOf('.');
        return i > 0 ? nombre.substring(0, i) : nombre;
    }

    /** Quita los caracteres que Windows no permite en nombres de archivo. */
    private static String limpiar(String nombre) {
        return nombre.replaceAll("[\\\\/:*?\"<>|]", "_");
    }
                

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        txtNombre = new javax.swing.JTextField();
        btnSubir = new javax.swing.JButton();
        btnAbrir = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        lblCoach = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();

        setLayout(new java.awt.BorderLayout());

        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        pnlForm.setForeground(new java.awt.Color(255, 255, 255));
        pnlForm.setPreferredSize(new java.awt.Dimension(300, 150));

        btnSubir.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnSubir.setText(" Subir archivo Excel");
        btnSubir.addActionListener(this::btnSubirActionPerformed);

        btnAbrir.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnAbrir.setText("Abrir archivo");
        btnAbrir.addActionListener(this::btnAbrirActionPerformed);

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnEliminar.setText("Eliminar");

        lblCoach.setForeground(new java.awt.Color(73, 80, 87));
        lblCoach.setText("Rutinas usuarios");

        javax.swing.GroupLayout pnlFormLayout = new javax.swing.GroupLayout(pnlForm);
        pnlForm.setLayout(pnlFormLayout);
        pnlFormLayout.setHorizontalGroup(
            pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFormLayout.createSequentialGroup()
                        .addComponent(lblCoach, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlFormLayout.createSequentialGroup()
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 104, Short.MAX_VALUE)
                        .addComponent(btnSubir, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(btnAbrir, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))))
        );
        pnlFormLayout.setVerticalGroup(
            pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblCoach, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSubir, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAbrir, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(61, 61, 61))
        );

        add(pnlForm, java.awt.BorderLayout.NORTH);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSubirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSubirActionPerformed

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAbrirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnSubir;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCoach;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
