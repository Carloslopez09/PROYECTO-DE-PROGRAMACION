/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package belensgym.vista;

/** Toda pantalla del menú implementa recargar() para refrescar sus datos al 
mostrarse. */
    public interface Recargable {
        void recargar();
}
