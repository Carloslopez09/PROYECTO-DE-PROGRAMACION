/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Estilo;
import belensgym.util.Sesion;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
/**
 *
 * @author carlo
 */
    /**
     * Creates new form Principal
     */
    public class Principal extends javax.swing.JFrame {
        private final Map<String, JButton> botones = new HashMap<>();
        private final JButton btnRutinas = new JButton("Rutinas");
        private final Map<String, Recargable> paneles = new HashMap<>();
        private String primero = null;
        
        public Principal() {
        initComponents();
        
        getContentPane().removeAll();
        getContentPane().setLayout(new java.awt.BorderLayout());
        pnlMenu.setPreferredSize(new java.awt.Dimension(220, 650));
        pnlContenido.setPreferredSize(new java.awt.Dimension(900, 650));
        pnlContenido.setLayout(new CardLayout());
        getContentPane().add(pnlMenu, java.awt.BorderLayout.WEST);
        getContentPane().add(pnlContenido, java.awt.BorderLayout.CENTER);
        
        setSize(1150, 700);
        setLocationRelativeTo(null);
        
        lblNombreMenu.setHorizontalAlignment(SwingConstants.CENTER);
        lblUsuario.setHorizontalAlignment(SwingConstants.CENTER);
        lblUsuario.setForeground(new Color(0xAD, 0xB5, 0xBD));
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblLogo.setBounds(65, 20, 90, 90);
        lblLogo.setBounds(65, 20, 90, 90);
        lblNombreMenu.setBounds(0, 115, 220, 26);
        lblUsuario.setBounds(0, 142, 220, 18);
        btnClientes.setBounds(0, 185, 220, 44);
        lblLogo.setBounds(65, 20, 90, 90);
        lblNombreMenu.setBounds(0, 115, 220, 26);
        lblUsuario.setBounds(0, 142, 220, 18);

        //iconos
        btnClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/clientes.png")));
        btnMembresias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/membresias_pagos.png")));
        btnCoaches.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/entrenadores.png")));
        btnAsistencia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/asistencia.png")));
        btnMaquinas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/maquinas.png")));
        btnMantenimiento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mantenimiento.png")));       
        btnReportes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reportes.png")));
        btnUsuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/usuarios.png")));
        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar_sesion.png")));
        
        
        pnlMenu.setLayout(null);
        
        
        
        // Agregar Rutinas al menú
        if (btnRutinas.getParent() == null) {
        pnlMenu.add(btnRutinas);
     }

// Los botones se acomodarán automáticamente
        JButton[] menu = {
        btnClientes,
        btnMembresias,
        btnCoaches,
        btnAsistencia,
        btnRutinas,
        btnMaquinas,
        btnMantenimiento,
        btnReportes,
        btnUsuarios,
        btnSalir
    };

        int posicionY = 185;

        for (JButton b : menu) {
        b.setBounds(0, posicionY, 220, 44);
        posicionY += 46;
    }
        setTitle("Belen's Gym VIP - " + Sesion.username + " (" + Sesion.rol + ")");
        
        ImageIcon logo = new 
        ImageIcon(getClass().getResource("/img/logo.jpeg"));
            lblLogo.setIcon(new 
        ImageIcon(logo.getImage().getScaledInstance(90, 90, 
         java.awt.Image.SCALE_SMOOTH)));
            lblUsuario.setText(Sesion.username + " - " + Sesion.rol);
    
        JButton[] todos = {btnClientes, btnMembresias, btnCoaches, btnAsistencia,btnRutinas,btnMaquinas, btnMantenimiento, btnReportes, btnUsuarios}; 
         for (JButton b : todos) {
            b.setVisible(false);
        }
        boolean admin = Sesion.esAdmin();
        boolean recep = Sesion.esRecepcion();
        boolean coach = Sesion.esCoach();
        
        registrar("clientes", btnClientes, admin || recep, () -> new PanelClientes());
        registrar("membresias", btnMembresias, admin || recep, () -> new PanelMembresias());
        registrar("coaches", btnCoaches, admin, () -> new PanelCoaches());
        registrar("rutinas", btnRutinas, coach,() -> new PanelRutinas());
        registrar("asistencia", btnAsistencia, admin || coach, () -> new PanelAsistencia());
        registrar("maquinas", btnMaquinas, admin || recep, () -> new PanelMaquinas());
        registrar("mantenimiento", btnMantenimiento, admin || recep, () -> new PanelMantenimiento());
        registrar("reportes", btnReportes, admin, () -> new PanelReportes());
        registrar("usuarios", btnUsuarios, admin, () -> new PanelUsuarios());
        acomodarMenu();
        
        estiloMenu(btnSalir, false);
        btnSalir.setForeground(new Color(0xFF, 0x8A, 0x8A));
        btnSalir.addActionListener(e -> {
            Sesion.cerrar();
            dispose();
            new Login().setVisible(true);
        });
        if (primero != null) {
            mostrar(primero);
        }
    }
    
      /** Agrega una pantalla al menú si el rol tiene permiso. */
        private void registrar(String clave, JButton boton, boolean permitido, 
            Supplier<JPanel> fabrica) {
            boton.setVisible(permitido);
            if (!permitido) {
            return;
        }
        JPanel p = fabrica.get();
        
        pnlContenido.add(p, clave);
        paneles.put(clave, (Recargable) p);
        botones.put(clave, boton);
        estiloMenu(boton, false);
        boton.addActionListener(e -> mostrar(clave));
        if (primero == null) {
            primero = clave;
        }
    }
    
        
    private void mostrar(String clave) {
        ((CardLayout) pnlContenido.getLayout()).show(pnlContenido, clave);
        paneles.get(clave).recargar();
        for (Map.Entry<String, JButton> e : botones.entrySet()) {
            estiloMenu(e.getValue(), e.getKey().equals(clave));
        }
    }   
    
      private void estiloMenu(JButton b, boolean activo) {
        b.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBackground(activo ? Estilo.NEGRO_SUAVE : Estilo.NEGRO);
        b.setForeground(activo ? Estilo.AMARILLO : Color.WHITE);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, activo ? 
                Estilo.AMARILLO : Estilo.NEGRO),
                BorderFactory.createEmptyBorder(0, 16, 0, 0)));
        }
    private void acomodarMenu() {
    JButton[] menu = {
        btnClientes,
        btnMembresias,
        btnCoaches,
        btnAsistencia,
        btnRutinas,
        btnMaquinas,
        btnMantenimiento,
        btnReportes,
        btnUsuarios
    };

    int posicionY = 185;

    for (JButton b : menu) {
        if (b.isVisible()) {
            b.setBounds(0, posicionY, 220, 44);
            posicionY += 46;
        }
    }

    // Cerrar sesión siempre queda abajo
    btnSalir.setBounds(0, 640, 220, 44);

    pnlMenu.revalidate();
    pnlMenu.repaint();
}  
      
      
        /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMenu = new javax.swing.JPanel();
        lblLogo = new javax.swing.JLabel();
        lblNombreMenu = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        btnClientes = new javax.swing.JButton();
        btnMembresias = new javax.swing.JButton();
        btnCoaches = new javax.swing.JButton();
        btnAsistencia = new javax.swing.JButton();
        btnMaquinas = new javax.swing.JButton();
        btnMantenimiento = new javax.swing.JButton();
        btnReportes = new javax.swing.JButton();
        btnUsuarios = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        pnlContenido = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1800, 598));

        pnlMenu.setBackground(new java.awt.Color(0, 0, 0));
        pnlMenu.setLayout(null);

        lblLogo.setPreferredSize(new java.awt.Dimension(40, 40));
        pnlMenu.add(lblLogo);
        lblLogo.setBounds(10, 10, 60, 70);

        lblNombreMenu.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        lblNombreMenu.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreMenu.setText("BELEN'S GYM VIP");
        pnlMenu.add(lblNombreMenu);
        lblNombreMenu.setBounds(80, 10, 60, 70);
        pnlMenu.add(lblUsuario);
        lblUsuario.setBounds(0, 0, 60, 70);

        btnClientes.setText("Clientes");
        pnlMenu.add(btnClientes);
        btnClientes.setBounds(30, 130, 72, 23);

        btnMembresias.setText("Membresias y Pagos");
        pnlMenu.add(btnMembresias);
        btnMembresias.setBounds(30, 180, 138, 23);

        btnCoaches.setText("Entrenadores");
        pnlMenu.add(btnCoaches);
        btnCoaches.setBounds(30, 230, 100, 23);

        btnAsistencia.setText("Asistencia");
        pnlMenu.add(btnAsistencia);
        btnAsistencia.setBounds(30, 280, 83, 23);

        btnMaquinas.setText("Maquinas");
        pnlMenu.add(btnMaquinas);
        btnMaquinas.setBounds(30, 330, 81, 23);

        btnMantenimiento.setText("Mantenimiento");
        pnlMenu.add(btnMantenimiento);
        btnMantenimiento.setBounds(30, 390, 111, 23);

        btnReportes.setText("Reportes");
        pnlMenu.add(btnReportes);
        btnReportes.setBounds(30, 440, 77, 23);

        btnUsuarios.setText("Usuario");
        pnlMenu.add(btnUsuarios);
        btnUsuarios.setBounds(30, 490, 72, 23);

        btnSalir.setText("Cerrar Sesion");
        pnlMenu.add(btnSalir);
        btnSalir.setBounds(30, 540, 120, 23);

        pnlContenido.setBackground(new java.awt.Color(241, 243, 245));
        pnlContenido.setPreferredSize(new java.awt.Dimension(400, 600));

        javax.swing.GroupLayout pnlContenidoLayout = new javax.swing.GroupLayout(pnlContenido);
        pnlContenido.setLayout(pnlContenidoLayout);
        pnlContenidoLayout.setHorizontalGroup(
            pnlContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1200, Short.MAX_VALUE)
        );
        pnlContenidoLayout.setVerticalGroup(
            pnlContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 592, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlContenido, javax.swing.GroupLayout.PREFERRED_SIZE, 1200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pnlContenido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE)
                    .addComponent(pnlMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
  
    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAsistencia;
    private javax.swing.JButton btnClientes;
    private javax.swing.JButton btnCoaches;
    private javax.swing.JButton btnMantenimiento;
    private javax.swing.JButton btnMaquinas;
    private javax.swing.JButton btnMembresias;
    private javax.swing.JButton btnReportes;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnUsuarios;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblNombreMenu;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPanel pnlContenido;
    private javax.swing.JPanel pnlMenu;
    // End of variables declaration//GEN-END:variables
}
