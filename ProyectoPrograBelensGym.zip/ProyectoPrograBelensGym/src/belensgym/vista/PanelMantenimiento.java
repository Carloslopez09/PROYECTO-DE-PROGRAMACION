/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package belensgym.vista;

import belensgym.util.Db;
import belensgym.util.Estilo;
import belensgym.util.Sesion;
import belensgym.util.Ui;
import java.awt.event.ItemEvent;
import java.math.BigDecimal;
import java.sql.SQLException;
import javax.swing.ImageIcon;


/**
 *
 * @author carlo
 */
public class PanelMantenimiento extends javax.swing.JPanel implements Recargable {
 
    public PanelMantenimiento() {
        initComponents();
        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"CORRECTIVO", "PREVENTIVO"}));
        Estilo.tabla(tabla);
        Estilo.campo(txtFinEstimado, txtCosto, txtDescripcion);
        Estilo.primario(btnRegistrar);
        Estilo.secundario(btnProceso);
        Estilo.secundario(btnFinalizar);
        mostrarFoto(null);
 
        btnRegistrar.addActionListener(e -> registrar());
        btnProceso.addActionListener(e -> enProceso());
        btnFinalizar.addActionListener(e -> finalizar());
 
        // Al elegir una máquina en el combo se muestra su foto
        cmbMaquina.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                Ui.Item maq = Ui.item(cmbMaquina);
                fotoDeMaquina(maq == null ? null : maq.id);
            }
        });
        // Al seleccionar un registro de la tabla se muestra la foto de su máquina
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fotoDeMantenimiento();
            }
        });
        recargar();
    }
    
    @Override
    public void recargar() {
        try {
            Ui.cargarCombo(cmbMaquina, "SELECT id_maquina, CONCAT(nombre,' (',estado,')') FROM maquinas ORDER BY nombre");
            tabla.setModel(Db.consultar(
                    "SELECT mt.id_mantenimiento AS `ID`, ma.nombre AS `Máquina`, mt.tipo AS `Tipo`, "
                    + "mt.descripcion AS `Descripción`, mt.fecha_reporte AS `Reporte`, "
                    + "mt.fecha_estimada_fin AS `Fin estimado`, mt.fecha_fin AS `Finalizado`, "
                    + "mt.costo AS `Costo`, mt.estado AS `Estado` FROM mantenimientos mt "
                    + "JOIN maquinas ma ON ma.id_maquina = mt.id_maquina ORDER BY mt.id_mantenimiento DESC"));
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
    
    private void mostrarFoto(byte[] datos) {
        if (datos == null) {
            lblFoto.setIcon(null);
            lblFoto.setText("Sin foto");
            return;
        }
        int w = (lblFoto.getWidth() > 0 ? lblFoto.getWidth() : 140) - 2;
        int h = (lblFoto.getHeight() > 0 ? lblFoto.getHeight() : 150) - 2;
        ImageIcon original = new ImageIcon(datos);
        double escala = Math.min((double) w / original.getIconWidth(), (double) h / original.getIconHeight());
        int nw = Math.max(1, (int) (original.getIconWidth() * escala));
        int nh = Math.max(1, (int) (original.getIconHeight() * escala));
        lblFoto.setText("");
        lblFoto.setIcon(new ImageIcon(original.getImage().getScaledInstance(nw, nh, java.awt.Image.SCALE_SMOOTH)));
    }
 
    /** Foto de la máquina elegida en el combo. */
    private void fotoDeMaquina(Integer idMaquina) {
        if (idMaquina == null) {
            mostrarFoto(null);
            return;
        }
        try {
            Object f = Db.escalar("SELECT foto FROM maquinas WHERE id_maquina=?", idMaquina);
            mostrarFoto(f instanceof byte[] ? (byte[]) f : null);
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    /** Foto de la máquina del mantenimiento seleccionado en la tabla. */
    private void fotoDeMantenimiento() {
        if (tabla.getSelectedRow() < 0) {
            return;
        }
        Integer id = Ui.id(tabla);
        if (id == null) {
            return;
        }
        try {
            Object f = Db.escalar("SELECT ma.foto FROM mantenimientos mt "
                    + "JOIN maquinas ma ON ma.id_maquina = mt.id_maquina WHERE mt.id_mantenimiento=?", id);
            mostrarFoto(f instanceof byte[] ? (byte[]) f : null);
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    // ---------- Mantenimientos ----------
 
    /** Lee el costo del campo (acepta coma o punto decimal). Devuelve null si está vacío. */
    private BigDecimal costo() {
        String s = txtCosto.getText().trim().replace(",", ".");
        return s.isEmpty() ? null : new BigDecimal(s);
    }
 
    private void registrar() {
        Ui.Item maq = Ui.item(cmbMaquina);
        String desc = txtDescripcion.getText().trim();
        if (maq == null || desc.isEmpty()) {
            Ui.error(this, "Selecciona la máquina y escribe la descripción.");
            return;
        }
        java.sql.Date fin;
        BigDecimal costo;
        try {
            fin = Ui.fecha(txtFinEstimado.getText());
            costo = costo();
        } catch (IllegalArgumentException e) {
            Ui.error(this, "Revisa la fecha (AAAA-MM-DD) y el costo (solo números).");
            return;
        }
        String tipo = (String) cmbTipo.getSelectedItem();
        try {
            Db.ejecutar("INSERT INTO mantenimientos(id_maquina, id_usuario, tipo, descripcion, fecha_reporte, "
                    + "fecha_estimada_fin, costo) VALUES(?,?,?,?,CURDATE(),?,?)",
                    maq.id, Sesion.idUsuario, tipo, desc, fin, costo);
            // Una falla deja la máquina fuera de servicio; un preventivo, en mantenimiento
            Db.ejecutar("UPDATE maquinas SET estado=? WHERE id_maquina=?",
                    "CORRECTIVO".equals(tipo) ? "FUERA_DE_SERVICIO" : "EN_MANTENIMIENTO", maq.id);
            txtDescripcion.setText("");
            txtFinEstimado.setText("");
            txtCosto.setText("");
            Ui.info(this, "Mantenimiento registrado. El estado de la máquina fue actualizado.");
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    private void enProceso() {
        Integer id = Ui.id(tabla);
        if (id == null) {
            Ui.error(this, "Selecciona un registro de la tabla.");
            return;
        }
        if ("FINALIZADO".equals(Ui.txt(tabla, 8))) {
            Ui.error(this, "Ese mantenimiento ya está finalizado.");
            return;
        }
        try {
            Db.ejecutar("UPDATE mantenimientos SET estado='EN_PROCESO' WHERE id_mantenimiento=?", id);
            Db.ejecutar("UPDATE maquinas SET estado='EN_MANTENIMIENTO' WHERE id_maquina="
                    + "(SELECT id_maquina FROM mantenimientos WHERE id_mantenimiento=?)", id);
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }
 
    private void finalizar() {
        Integer id = Ui.id(tabla);
        if (id == null) {
            Ui.error(this, "Selecciona un registro de la tabla.");
            return;
        }
        if ("FINALIZADO".equals(Ui.txt(tabla, 8))) {
            Ui.error(this, "Ese mantenimiento ya está finalizado.");
            return;
        }
        BigDecimal costo;
        try {
            costo = costo();
        } catch (NumberFormatException e) {
            Ui.error(this, "El costo debe ser un número.");
            return;
        }
        try {
            Db.ejecutar("UPDATE mantenimientos SET estado='FINALIZADO', fecha_fin=CURDATE(), "
                    + "costo=COALESCE(?, costo) WHERE id_mantenimiento=?", costo, id);
            // La máquina vuelve a estar disponible si no le quedan mantenimientos abiertos
            Db.ejecutar("UPDATE maquinas SET estado='DISPONIBLE' WHERE id_maquina="
                    + "(SELECT id_maquina FROM mantenimientos WHERE id_mantenimiento=?) "
                    + "AND NOT EXISTS (SELECT 1 FROM mantenimientos x "
                    + "WHERE x.id_maquina = maquinas.id_maquina AND x.estado <> 'FINALIZADO')", id);
            txtCosto.setText("");
            Ui.info(this, "Mantenimiento finalizado.");
            recargar();
        } catch (SQLException e) {
            Ui.error(this, e);
        }
    }

       
 
  

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForm = new javax.swing.JPanel();
        lblNombre3 = new javax.swing.JLabel();
        cmbTipo = new javax.swing.JComboBox<>();
        lblNombre4 = new javax.swing.JLabel();
        cmbMaquina = new javax.swing.JComboBox<>();
        lblNombre5 = new javax.swing.JLabel();
        txtFinEstimado = new javax.swing.JTextField();
        lblNombre6 = new javax.swing.JLabel();
        txtCosto = new javax.swing.JTextField();
        lblNombre7 = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        btnRegistrar = new javax.swing.JButton();
        btnProceso = new javax.swing.JButton();
        btnFinalizar = new javax.swing.JButton();
        lblFoto = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();

        setLayout(new java.awt.BorderLayout());

        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        pnlForm.setPreferredSize(new java.awt.Dimension(949, 316));
        pnlForm.setLayout(null);

        lblNombre3.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre3.setText("Costo (Q)");
        pnlForm.add(lblNombre3);
        lblNombre3.setBounds(810, 30, 100, 30);

        cmbTipo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pnlForm.add(cmbTipo);
        cmbTipo.setBounds(290, 60, 220, 40);

        lblNombre4.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre4.setText("Descripcion");
        pnlForm.add(lblNombre4);
        lblNombre4.setBounds(20, 130, 90, 30);

        cmbMaquina.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbMaquina.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pnlForm.add(cmbMaquina);
        cmbMaquina.setBounds(20, 60, 220, 40);

        lblNombre5.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre5.setText("Tipo");
        pnlForm.add(lblNombre5);
        lblNombre5.setBounds(290, 30, 90, 30);

        txtFinEstimado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtFinEstimado);
        txtFinEstimado.setBounds(570, 60, 190, 40);

        lblNombre6.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre6.setText("Fin estimado (AAAA-MM-DD)");
        pnlForm.add(lblNombre6);
        lblNombre6.setBounds(570, 30, 170, 30);

        txtCosto.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlForm.add(txtCosto);
        txtCosto.setBounds(810, 60, 130, 40);

        lblNombre7.setForeground(new java.awt.Color(73, 80, 87));
        lblNombre7.setText("Maquina");
        pnlForm.add(lblNombre7);
        lblNombre7.setBounds(20, 30, 90, 30);
        pnlForm.add(txtDescripcion);
        txtDescripcion.setBounds(20, 160, 920, 40);

        btnRegistrar.setBackground(new java.awt.Color(255, 204, 102));
        btnRegistrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnRegistrar.setText("Resgistrar mantenimiento");
        pnlForm.add(btnRegistrar);
        btnRegistrar.setBounds(20, 240, 220, 40);

        btnProceso.setBackground(new java.awt.Color(0, 0, 0));
        btnProceso.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnProceso.setForeground(new java.awt.Color(255, 255, 255));
        btnProceso.setText("Marcar proceso");
        pnlForm.add(btnProceso);
        btnProceso.setBounds(270, 240, 150, 40);

        btnFinalizar.setBackground(new java.awt.Color(0, 0, 0));
        btnFinalizar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFinalizar.setForeground(new java.awt.Color(255, 255, 255));
        btnFinalizar.setText("Finalizar seleccionado");
        pnlForm.add(btnFinalizar);
        btnFinalizar.setBounds(450, 240, 200, 40);

        lblFoto.setText("                               Sin foto");
        lblFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pnlForm.add(lblFoto);
        lblFoto.setBounds(990, 20, 250, 260);

        add(pnlForm, java.awt.BorderLayout.NORTH);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFinalizar;
    private javax.swing.JButton btnProceso;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JComboBox<String> cmbMaquina;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JLabel lblNombre3;
    private javax.swing.JLabel lblNombre4;
    private javax.swing.JLabel lblNombre5;
    private javax.swing.JLabel lblNombre6;
    private javax.swing.JLabel lblNombre7;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtFinEstimado;
    // End of variables declaration//GEN-END:variables
}
