package belensgym.util;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/** Utilidades de interfaz y validación. */
public class Ui {

    /** Elemento para combos: guarda el id y el texto a mostrar. */
    public static class Item {
        public final int id;
        public final String texto;

        public Item(int id, String texto) {
            this.id = id;
            this.texto = texto;
        }

        @Override
        public String toString() {
            return texto;
        }
    }

    public static void info(Component c, String msg) {
        JOptionPane.showMessageDialog(c, msg, "Belems Gym", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(Component c, String msg) {
        JOptionPane.showMessageDialog(c, msg, "Belems Gym", JOptionPane.ERROR_MESSAGE);
    }

    public static void error(Component c, Exception e) {
        error(c, "Ocurrió un error:\n" + e.getMessage());
    }

    public static boolean confirmar(Component c, String msg) {
        return JOptionPane.showConfirmDialog(c, msg, "Confirmar", JOptionPane.YES_NO_OPTION)
                == JOptionPane.YES_OPTION;
    }

    public static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /** "2026-10-30" -> Date. Vacío -> null. Formato incorrecto -> IllegalArgumentException. */
    public static java.sql.Date fecha(String s) {
        if (s == null || s.trim().isEmpty()) {
            return null;
        }
        return java.sql.Date.valueOf(s.trim());
    }

    /** Texto vacío -> null. */
    public static String nul(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }

    public static JTable tabla() {
        JTable t = new JTable();
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.setRowHeight(24);
        t.setAutoCreateRowSorter(true);
        t.setFillsViewportHeight(true);
        return t;
    }

    public static Object celda(JTable t, int col) {
        int r = t.getSelectedRow();
        if (r < 0) {
            return null;
        }
        return t.getModel().getValueAt(t.convertRowIndexToModel(r), col);
    }

    public static String txt(JTable t, int col) {
        Object o = celda(t, col);
        return o == null ? "" : o.toString();
    }

    /** Id de la fila seleccionada (columna 0) o null. */
    public static Integer id(JTable t) {
        Object o = celda(t, 0);
        return o == null ? null : Integer.valueOf(((Number) o).intValue());
    }

    /** Formulario: pares ("Etiqueta:", componente), dos pares por fila. */
    public static JPanel form(Object... lc) {
        JPanel p = new JPanel(new GridLayout(0, 4, 10, 8));
        for (int i = 0; i < lc.length; i += 2) {
            p.add(new JLabel((String) lc[i]));
            p.add((JComponent) lc[i + 1]);
        }
        if ((lc.length / 2) % 2 == 1) {
            p.add(new JLabel());
            p.add(new JLabel());
        }
        return p;
    }

    public static JPanel botones(JButton... bs) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        for (JButton b : bs) {
            p.add(b);
        }
        return p;
    }

    /** Llena un combo con una consulta que devuelve (id, texto). Conserva la selección. */
    public static void cargarCombo(JComboBox cb, String sql, Object... p) {
    try {
        Item sel = item(cb);
        DefaultTableModel m = Db.consultar(sql, p);
        cb.removeAllItems();
        Item reponer = null;
        for (int i = 0; i < m.getRowCount(); i++) {
            Item it = new Item(((Number) m.getValueAt(i, 0)).intValue(), 
                    String.valueOf(m.getValueAt(i, 1)));
                        cb.addItem(it);
                        if (sel != null && sel.id == it.id) {
                            reponer = it;
                        }
                    }
                if (reponer != null) {
                cb.setSelectedItem(reponer);
            }
        } catch (SQLException e) {
       error(cb, e);
    }
}
/** Elemento seleccionado de un combo cargado con cargarCombo (o null). */
@SuppressWarnings("rawtypes")
public static Item item(JComboBox cb) {
Object o = cb.getSelectedItem();
return (o instanceof Item) ? (Item) o : null;
}

    /** Exporta el contenido de una tabla a un archivo CSV (se abre con Excel). */
    public static void exportarCsv(Component parent, JTable t) {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("reporte.csv"));
        if (fc.showSaveDialog(parent) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        try (PrintWriter w = new PrintWriter(new OutputStreamWriter(new FileOutputStream(fc.getSelectedFile()), "UTF-8"))) {
            w.print('\uFEFF');
            TableModel m = t.getModel();
            for (int c = 0; c < m.getColumnCount(); c++) {
                w.print((c > 0 ? "," : "") + csv(m.getColumnName(c)));
            }
            w.println();
            for (int r = 0; r < m.getRowCount(); r++) {
                for (int c = 0; c < m.getColumnCount(); c++) {
                    Object v = m.getValueAt(r, c);
                    w.print((c > 0 ? "," : "") + csv(v == null ? "" : v.toString()));
                }
                w.println();
            }
            info(parent, "Archivo guardado:\n" + fc.getSelectedFile().getAbsolutePath());
        } catch (Exception e) {
            error(parent, e);
        }
    }

    private static String csv(String s) {
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    public static JPanel margen(JPanel p) {
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return p;
    }
}
