package belensgym.util;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.Icon;

/**
 * Icono que ajusta una imagen al tamaño indicado conservando sus proporciones
 * y con buena calidad (también en pantallas con zoom de Windows).
 * Uso: label.setIcon(new IconoEscalado("/img/logo.png", 190, 190));
 */
public class IconoEscalado implements Icon {
    private final BufferedImage img;
    private final int ancho;
    private final int alto;

    public IconoEscalado(String ruta, int maxAncho, int maxAlto) {
        BufferedImage original = null;
        try {
            URL url = IconoEscalado.class.getResource(ruta);
            if (url != null) {
                original = ImageIO.read(url);
            }
        } catch (Exception e) {
            original = null;
        }
        if (original == null) {
            this.img = null;
            this.ancho = 1;
            this.alto = 1;
            return;
        }
        double escala = Math.min((double) maxAncho / original.getWidth(), (double) maxAlto / original.getHeight());
        this.ancho = Math.max(1, (int) Math.round(original.getWidth() * escala));
        this.alto = Math.max(1, (int) Math.round(original.getHeight() * escala));

        // Se reduce a la mitad varias veces hasta quedar a menos del doble del tamaño final:
        // así no se pierden detalles (evita bordes dentados) y queda nítido en pantallas con zoom.
        BufferedImage actual = original;
        while (actual.getWidth() / 2 >= this.ancho * 2 && actual.getHeight() / 2 >= this.alto * 2) {
            actual = reducir(actual, actual.getWidth() / 2, actual.getHeight() / 2);
        }
        this.img = actual;
    }

    private static BufferedImage reducir(BufferedImage src, int w, int h) {
        BufferedImage dst = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = dst.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(src, 0, 0, w, h, null);
        g.dispose();
        return dst;
    }

    @Override
    public int getIconWidth() {
        return ancho;
    }

    @Override
    public int getIconHeight() {
        return alto;
    }

    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {
        if (img == null) {
            return;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.drawImage(img, x, y, ancho, alto, null);
        g2.dispose();
    }
}