package belensgym.util;

/** Guarda al usuario que inició sesión. */
public class Sesion {
    public static int idUsuario;
    public static String username;
    public static String rol;          // ADMINISTRADOR, COACH, RECEPCIONISTA
    public static Integer idCoach;     // solo si el usuario es un coach

    public static boolean esAdmin()  { return "ADMINISTRADOR".equals(rol); }
    public static boolean esCoach()  { return "COACH".equals(rol); }
    public static boolean esRecepcion() { return "RECEPCIONISTA".equals(rol); }

    public static void cerrar() {
        idUsuario = 0;
        username = null;
        rol = null;
        idCoach = null;
    }
}
