/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package belensgym.util;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.JTextComponent;
/**
 *
 * @author carlo
 */
public class Estilo {

    public static final Color NEGRO = new Color(0x21, 0x25, 0x29);
    public static final Color NEGRO_SUAVE = new Color(0x34, 0x3A, 0x40);
    public static final Color AMARILLO = new Color(0xFF, 0xC1, 0x07);
    public static final Color AMARILLO_SUAVE = new Color(0xFF, 0xF3, 0xBF);
    public static final Color FONDO = new Color(0xF1, 0xF3, 0xF5);
    public static final Color BORDE = new Color(0xCE, 0xD4, 0xDA);
    public static final Color GRIS = new Color(0x6C, 0x75, 0x7D);
    public static final Color ROJO = new Color(0xE0, 0x31, 0x31);
    
    private static void boton(JButton b, Color fondo, Color texto) {
        b.setBackground(fondo);
        b.setForeground(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }  
    
     /** Botón principal: amarillo con texto negro. */
    public static void primario(JButton b) {
        boton(b, AMARILLO, NEGRO);
    }
    /** Botón secundario: negro con texto blanco. */
    public static void secundario(JButton b) {
        boton(b, NEGRO, Color.WHITE);
    }
    /** Botón de peligro: rojo con texto blanco. */
    public static void peligro(JButton b) {
        boton(b, ROJO, Color.WHITE);
    }
    
     public static void campo(JTextComponent... campos) {
        for (JTextComponent c : campos) {
            c.setBackground(new Color(0xF8, 0xF9, 0xFA));
            c.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDE), new EmptyBorder(0, 
8, 0, 8)));
        }
    }
     
      /** Tabla con encabezado negro, filas amplias y selección amarilla. */
    public static void tabla(JTable t) {
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.setAutoCreateRowSorter(true);
        t.setRowHeight(26);
        t.setFillsViewportHeight(true);
        t.setShowVerticalLines(false);
        t.setGridColor(BORDE);
        t.setSelectionBackground(AMARILLO_SUAVE);
        t.setSelectionForeground(NEGRO);
        
     DefaultTableCellRenderer cabecera = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tb, Object 
                    v, boolean sel,
                    boolean foco, int fila, int col) {
                super.getTableCellRendererComponent(tb, v, sel, foco, fila, 
col);
                setBackground(NEGRO);
                setForeground(Color.WHITE);
                setFont(getFont().deriveFont(Font.BOLD));
                setBorder(new EmptyBorder(0, 8, 0, 8));
                return this;
            }
        };
        t.getTableHeader().setDefaultRenderer(cabecera);
        t.getTableHeader().setPreferredSize(new Dimension(0, 30));
    }    
}
