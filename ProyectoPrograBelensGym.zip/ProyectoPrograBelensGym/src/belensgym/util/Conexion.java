package belensgym.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    // ====== CAMBIA ESTOS DATOS SEGÚN TU MYSQL ======
    private static final String URL = "jdbc:mysql://localhost:3306/belems_gym"
            + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=America/Guatemala";
    private static final String USER = "gym";
    private static final String PASS = "gym1234";   // pon aquí tu contraseña (vacía si usas XAMPP)
    // ================================================

    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
